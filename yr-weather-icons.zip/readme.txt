Icons for use with yr.no weather service.
Icons are included in 72px png and in vector format through a PSD file.

Updated with icons a bit more optimized for a white background.

Copyright (C) 2012 Andreas Hellqvist. All rights reserved.
The icons are licensed under a Creative Commons Attribution
3.0 license. <http://creativecommons.org/licenses/by/3.0/>

<www.andreashellqvist.se>